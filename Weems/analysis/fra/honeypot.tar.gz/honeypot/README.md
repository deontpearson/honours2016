# http_honeypot
Repo URL: https://github.com/deontp/http_honeypot.git

My Honours project for 2016

