#!/bin/bash
# Builds the main.py file with custom modules, then runs the main.py file
#python "$DIR/delay30.py"

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
BUILD="$DIR/build-server.sh"
START="$DIR/start-server.sh ip=196.21.242.120 port=80 debug=false"
#python "$DIR/delay30.py"
sudo $BUILD
sudo $START
